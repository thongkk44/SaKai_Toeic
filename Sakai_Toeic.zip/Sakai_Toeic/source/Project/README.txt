Download xampp to -> Unzip the directory thitoeic.zip into htdocs -> Go to phpMyadmin import the file thitoeic.sql to. -> Run localhost as usual
