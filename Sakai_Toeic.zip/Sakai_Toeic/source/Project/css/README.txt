This folder contain style web which is used in my website
