<div class="footer">
          <h1>This is the Footer</h1>
</div>