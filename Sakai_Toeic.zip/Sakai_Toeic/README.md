# Word of the day

Please view file "doc\plan\Project_CM-Plan.xlsx" to understand the folder structure.